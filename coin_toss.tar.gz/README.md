# coin-toss

To get a text output:
```bash
php test.php
```

## Documentation
Use doxygen to generete documentation:
```bash
doxygen doxyfile.doc
```
