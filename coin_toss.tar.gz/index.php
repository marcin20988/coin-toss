<html>
  <head>
    <link rel="stylesheet" type="text/css" href="css/index.css">
  </head>
  <body>
    <h1>Coin toss tournament</h1>
    <a href='html/index.html' target='_blank'>Documentation</a>
    <a href='https://github.com/marcin20988/coin-toss' target='_blank'>Get files (github)</a>
    <a href='coin_toss.tar.gz' target='_blank'>Get files (coint_toss.tar.gz)</a>
    <a href='play.php' class="tournament-link">Play a tournament here</a>
  </body>
</html>

